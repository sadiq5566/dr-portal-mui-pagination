declare module "*.png" {
  export default "" as string;
}
declare module "react-router-dom";
