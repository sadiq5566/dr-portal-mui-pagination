/* eslint-disable @typescript-eslint/no-explicit-any */
import axios, { AxiosRequestConfig, Method } from "axios";

export const baseURL = "https://dev.api.deputyregistrar.net";
export const accept = "application/vnd.api+json";
export const getToken = async () => {
  return "eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImpQUzRQbnlDZWR3SjdGc3pLMXoyQyJ9.eyJodHRwczovL2Rldi5kZXB1dHlyZWdpc3RyYXIubmV0L3JvbGVzIjpbIlN1cGVyLUFkbWluIl0sImlzcyI6Imh0dHBzOi8vZHItcG9ydGVyLWRldi51cy5hdXRoMC5jb20vIiwic3ViIjoiYXV0aDB8NjBkMzgwODNmYjE0NmYwMDY5MDRkNTg2IiwiYXVkIjpbImh0dHBzOi8vZGV2LmRlcHV0eXJlZ2lzdHJhci5uZXQiLCJodHRwczovL2RyLXBvcnRlci1kZXYudXMuYXV0aDAuY29tL3VzZXJpbmZvIl0sImlhdCI6MTY1MDg2NTM4OSwiZXhwIjoxNjUwOTUxNzg5LCJhenAiOiJReWU2ZVVralR6ZVlZZ01NTFVIS0xVa0lUZ0w3dXA3UyIsInNjb3BlIjoib3BlbmlkIHByb2ZpbGUgZW1haWwiLCJwZXJtaXNzaW9ucyI6WyJhZG1pbiJdfQ.kJrQSOLLgETPHkgIMyPOc6cF0AUBKvABwAwzS1_Xeiy9iJdJlJ-kQ3TqroksPayoymYlk-7tVWkPZxryP4imkkEwjRccrVJSTVH3qqxosBgNIMcZMxwqUxHgw06IOkeX_MaMQj-2Kek5Eiyo7o7xRhBpfu_5T84cq8HzxYwpDSKa3N-He66GibkDlp0f9xC0EWJumhpU4ntLRp27l-Xj3PzTmpYeQz9U8KkVKdSLV_KpN4cPmtNJtlT1jOZh0pMzCLFgzzxHCl4riWDw5repRj7aGcj9enXQXL6A6Fn4pxUV0OY629VIUfJstPL0nCo7G6mX4lv0okpDcUVOeVGiRQ";
};

// Create Axios body
export const axiosBody = async (methods: Method, url: string, body?: any) => {
  const token = await getToken();
  const config: AxiosRequestConfig = {
    method: methods,
    url: `${baseURL}${url}`,
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json"
    },
    // Accept: "application/vnd.api+json",
    data: JSON.stringify(body)
  };
  return config;
};
