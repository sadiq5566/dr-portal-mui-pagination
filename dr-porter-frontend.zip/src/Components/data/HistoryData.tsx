const HistoryData = [
  {
    id: "1",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "complete"
  },
  {
    id: "2",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "reject"
  },
  {
    id: "3",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "locked"
  },
  {
    id: "4",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "new"
  },
  {
    id: "5",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "reject"
  },
  {
    id: "6",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "locked"
  },
  {
    id: "7",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "complete"
  },
  {
    id: "8",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "new"
  },
  {
    id: "9",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "accept"
  },
  {
    id: "10",
    orderNo: "Order No. 1245754",
    name: "User Name",
    time: "9:05 PM",
    orderStatus: "Order Completed",
    status: "reject"
  }
];
export default HistoryData;
