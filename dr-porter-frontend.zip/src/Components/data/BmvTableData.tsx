export const BmvOwnersData = [
  {
    id: "1",
    name: "James Smith",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "2",
    name: "Elizabeth David",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Disabled",
    button: "button"
  },
  {
    id: "3",
    name: "John Doe",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "4",
    name: "Maria Rodriguez",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "5",
    name: "Michael Smith",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "6",
    name: "Nancy Stuart",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Active",
    button: "button",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA"
  },
  {
    id: "7",
    name: "jane Goldsmith",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Disabled",
    button: "button"
  },
  {
    id: "8",
    name: "Jane Wilson",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "9",
    name: "Don Hemsworth",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "10",
    name: "Ben Afleck",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  }
];

export const BmvManagersData = [
  {
    id: "1",
    name: "James Smith",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "2",
    name: "Elizabeth David",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Disabled",
    button: "button"
  },
  {
    id: "3",
    name: "John Doe",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "4",
    name: "Maria Rodriguez",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "5",
    name: "Michael Smith",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "6",
    name: "Nancy Stuart",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "7",
    name: "jane Goldsmith",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Disabled",
    button: "button"
  },
  {
    id: "8",
    name: "Jane Wilson",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "9",
    name: "Don Hemsworth",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  },
  {
    id: "10",
    name: "Ben Afleck",
    BMV: "BMV Name Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    status: "Active",
    button: "button"
  }
];

export const BmvEmployeesData = [
  {
    id: "1",
    name: "James Smith",
    BMV: "BMV Name Here",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "2",
    name: "Elizabeth David",
    BMV: "BMV Name Here",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Disabled",
    button: "button"
  },
  {
    id: "3",
    name: "John Doe",
    BMV: "BMV Name Here",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "4",
    name: "Maria Rodriguez",
    BMV: "BMV Name Here",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "5",
    name: "Michael Smith",
    BMV: "BMV Name Here",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "6",
    name: "Nancy Stuart",
    BMV: "BMV Name Here",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "7",
    name: "jane Goldsmith",
    BMV: "BMV Name Here",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Disabled",
    button: "button"
  },
  {
    id: "8",
    name: "Jane Wilson",
    BMV: "BMV Name Here",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "9",
    name: "Don Hemsworth",
    BMV: "BMV Name Here",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  },
  {
    id: "10",
    name: "Ben Afleck",
    BMV: "BMV Name Here",
    Designation: "designation Here",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    button: "button"
  }
];

export const BmvLocationsData = [
  {
    id: "1",
    name: "James Smith",
    phone: "(844) 6446268",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    email: "contact@someemail.com",
    status: "Active",
    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  },
  {
    id: "2",
    name: "Elizabeth David",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Disabled",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  },
  {
    id: "3",
    name: "John Doe",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Active",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  },
  {
    id: "4",
    name: "Maria Rodriguez",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Active",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  },
  {
    id: "5",
    name: "Michael Smith",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Active",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  },
  {
    id: "6",
    name: "Nancy Stuart",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Active",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  },
  {
    id: "7",
    name: "jane Goldsmith",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Disabled",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  },
  {
    id: "8",
    name: "Jane Wilson",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Active",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  },
  {
    id: "9",
    name: "Don Hemsworth",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    status: "Active",
    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  },
  {
    id: "10",
    name: "Ben Afleck",
    phone: "(844) 6446268",
    email: "contact@someemail.com",
    status: "Active",
    image:
      "https://s3-alpha-sig.figma.com/img/e06b/4cb7/8254843536cb0efd337cd5ec9a516b41?Expires=1650844800&Signature=ULxuiCVQaOemAoUiAjZVD-5raSScA488msb-LSH9FvwXLgs1-frQ9iDffDOibvSZcNs1eOIow9bW2Cr5JHRtHr60tt1npzQQTsPJIBqDqgR9uyurtsr5oqTIpCqYmexp-XwP7dlWrc~iBd2eReBPBduxUJY14Tap5ni53IGFn-j2ZyxyjmmQgeW4xVtZpxVBmgNZ9VSqQUrndYNfc56DFVqshlgAn3~mbOWS45tVOXr8vqVoQd-YEIXSGq8Mj0SNflw6TcCURmaeoMdt9UiXIWFI6doTW1kan0jDRcTAtmr56PuIUP~URYWvdQdf6PmexfsQdQwKuRYcbMJhi0fyLQ__&Key-Pair-Id=APKAINTVSUGEWH5XD5UA",

    StripeAccount: "contact@someemail.com",
    PhysicalAddress: "1970 West Broad St. Columbus, Ohio 43223",
    button: "button"
  }
];
